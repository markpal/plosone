#ifndef NUSSINOV_TS4R_H
#define NUSSINOV_TS4R_H

#include "nussinov.h"

// May support samples up to 1M long
int nussinov_ts4r(const std::string &sample);

#endif // TRACO_NUSSINOV_S4R_H
