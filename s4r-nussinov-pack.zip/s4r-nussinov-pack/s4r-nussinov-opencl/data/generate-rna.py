import random
import sys

s = ''
for i in range(round(1024 * float(sys.argv[1]))):
    s += random.choice(['A', 'U', 'G', 'C'])

f = open("data.txt", "w")
f.write(s)
f.close()

