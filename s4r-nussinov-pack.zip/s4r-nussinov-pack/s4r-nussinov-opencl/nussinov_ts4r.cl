#ifndef CFG_IDE_PARSING

typedef int2 dvec;
typedef int3 sdvec;
// Multi-dimensional index shortcuts
#include "nussinov_ts4r_shortcuts.inc.cpp"

sdvec delta_max(const sdvec *v, const sdvec *w);
sdvec delta_max_glob(const sdvec *v, global const sdvec *w);
dvec  delta_max_aux(dvec v, dvec w, const int size);
dvec  discrete_vector(const int *vec, int size);
int   beta_score(char nt1, char nt2);

bool satisfy_sublogic(
    global char *g_table,
    global int *scores,
    global bool *octs,
           int low, int high,
           int a, int z,
           int n, int m, unsigned m_hash,
           int j, int g, int gp, int gn);

kernel void nussinov_ts4r_main_hndlr(
    global const char *sample,
    global dvec *mul_table,
    global char *g_table,
    global int *scores,
    global int *oct_scores,
    global bool *octs,
    global int *sig_oct,
    global sdvec *dmaxmul,
           int n, int q,
           int gn, int BS);

kernel void nussinov_ts4r_coarse_routine(
    global const char *sample,
    global dvec *mul_table,
    global char *g_table,
    global int *scores,
    global int *oct_scores,
    global bool *octs,
    global int *sig_oct,
    global sdvec *dmaxmul,
           int n, int q, int gn,
           int d, int BS, int ggp);

void nussinov_ts4r_routine(
    global dvec *mul_table,
    global char *g_table,
    global int *scores,
    global bool *octs,
    global int *sig_oct,
    global sdvec *dmaxmul,
           int n, int q,
           int j_low, int j_high,
           int gp, int gn, int BS);

kernel void initialize(
    global dvec *mul_table,
    global char *g_table,
    global int *scores,
    global int *oct_scores,
    global bool *octs,
    global int *sig_oct,
           int n,
           int gn,
           int q)
{
    const int q_max = (1 << q);
    const int q_hash = (q - 1) / 2 + 1.5;
    const int q_max_hash = (1 << q_hash);
    const int q_ghash = q / 2 + 1.5;
    const int q_max_ghash = (1 << q_ghash);

    const int rank = get_global_id(0);
    const int stride = get_global_size(0);

    // mul_table
    for (int i = rank; i < gn; i += stride)
    {
        for (int j = i; j < gn; ++j)
        {
            for (int k = 0; k < q_max_hash; ++k)
            {
                mul_table[mul_table_index(i, j, k, gn)] = (dvec) {-1, 0};
            }
        }
    }

    // g_table
    for (int i = rank; i < gn; i += stride)
    {
        for (int j = 0; j < q_max_ghash; ++j)
        {
            for (int k = 0; k < 2 * gn; ++k)
            {
                g_table[g_table_index(i, j, k, gn)] = 0;
            }
        }
    }

    // scores
    for (int i = rank; i < n + 1; i += stride)
    {
        for (int j = i; j < n + 1; ++j)
        {
            scores[scores_index(i, j, n)] = 0;
        }
    }

    // oct_scores
    for (int i = rank; i < n + 1; i += stride)
    {
        for (int j = 0; j < n + 1; ++j)
        {
            oct_scores[oct_scores_index(i, j, n)] = 0;
        }
    }

    // octs
    for (int i = rank; i < n + 1; i += stride)
    {
        for (int j = 0; j < n + 1; ++j)
        {
            octs[octs_index(i, j, n)] = true;
        }
    }

    // sig_oct
    for (int i = rank; i < gn; i += stride)
    {
        for (int j = 0; j < n + 1; ++j)
        {
            sig_oct[sig_oct_index(i, j, gn)] = q_max - 1;
        }
    }
}

kernel void nussinov_ts4r_main_hndlr(
    global const char *sample,
    global dvec *mul_table,
    global char *g_table,
    global int *scores,
    global int *oct_scores,
    global bool *octs,
    global int *sig_oct,
    global sdvec *dmaxmul,
           int n, int q,
           int gn, int BS)
{
    #if 0
    initialize(
      mul_table,
      g_table,
      scores,
      oct_scores,
      octs,
      sig_oct,
      n,
      gn,
      q);
    #endif

    for (int dd = 0; dd < gn; dd += BS)
    {
        for (int ggp = (gn - 1) - dd; ggp >= 0; ggp -= BS)
        {
            for (int d = dd; d < min(dd + BS, gn); ++d)
            {
                // PARCALL(BS, 1)

                nussinov_ts4r_coarse_routine(
                    sample,
                    mul_table,
                    g_table,
                    scores,
                    oct_scores,
                    octs,
                    sig_oct,
                    dmaxmul,
                    n, q, gn,
                    d, BS, ggp);

                // SYNC
            }
        }
    }
}

kernel void nussinov_ts4r_coarse_routine(
    global const char *sample,
    global dvec *mul_table,
    global char *g_table,
    global int *scores,
    global int *oct_scores,
    global bool *octs,
    global int *sig_oct,
    global sdvec *dmaxmul,
           int n, int q, int gn,
           int d, int BS, int ggp)
{
    const int rank = get_group_id(0);
    const int stride = get_num_groups(0);

    for (int gp = min(ggp, (gn - 1) - d) - rank; gp >= max(ggp - BS + 1, 0); gp -= stride)
    {
        int j_low, j_high;
        int gcount;
        sdvec maxmul[Q_LIMIT];

        const int local_rank = get_local_id(0);
        if (true || local_rank == 0) // TAKE HEED
        {
            j_low = q * (gp + d);
            j_high = min(j_low + (q - 1), n);

            // sdvec maxmul[Q_LIMIT];

            for (int i = 0; i < q; ++i)
            {
                maxmul[i] = (sdvec) {-1, 0, q - 1};
            }

            gcount = (j_high / q) - (gp + 1);
            for (int i = 0; i < q; ++i)
            {
                for (int j = 0; j < gcount; ++j)
                {
                    dmaxmul[dmaxmul_index(gp, i, j, q, gn, BS)] = (sdvec) {-1, 0, q - 1};
                }
            }
        }

        /**
         * Run blocks gp < g < gj
         */
        {
            barrier(CLK_LOCAL_MEM_FENCE | CLK_GLOBAL_MEM_FENCE);

            // PARCALL(gcount, 1)
            nussinov_ts4r_routine(
                mul_table,
                g_table,
                scores,
                octs,
                sig_oct,
                dmaxmul,
                n, q,
                j_low, j_high,
                gp, gn, BS
            );

            barrier(CLK_LOCAL_MEM_FENCE | CLK_GLOBAL_MEM_FENCE);
        }

        if (local_rank != 0)
          return;

        // Barrier
        // SYNC

        // Update maxmul
        for (int i = 0; i < q; ++i)
        {
            for (int j = 0; j < gcount; ++j)
            {
                maxmul[i] = delta_max_glob(&maxmul[i],
                    &dmaxmul[dmaxmul_index(gp, i, j, q, gn, BS)]);
            }
        }

        /**
         * Run blocks gp and gj
         */
        for (int j = j_low; j <= j_high; ++j)
        {
            // Shortcuts
            int jp = j - j_low;
            int gj = j / q;

            // Global boundaries
            int low = q * gp;
            int high = min(low + (q - 1), j - 2);

            // Initialization
            for (int i = high; i >= low; --i)
            {
                scores[scores_index(i, j, n)] = max(
                    max(
                        scores[scores_index(i, j - 1, n)],
                        scores[scores_index(i + 1, j, n)]
                    ),
                    oct_scores[oct_scores_index(i, j, n)] = scores[scores_index(i + 1, j - 1, n)]
                        + beta_score(sample[i], sample[j - 1])
                );
            };

            for (int g = gp; g <= gj; g = (g != gj) ? gj : gn)
            {
                // Particular boundaries
                int a = q * g;
                int z = min(a + (q - 1), j - 1);

                // Collecting L[g, j]
                int vec[Q_LIMIT];
                for (int i = 0; i < q; ++i)
                {
                    vec[i] = 0;
                }

                int kp = 0;
                for (int k = a; k <= z; ++k, ++kp)
                {
                    vec[kp] = scores[scores_index(k, j, n)];
                }

                if (kp > 0) // Stuff vector entries
                {
                    int lastval = vec[kp - 1];
                    while (kp < q)
                    {
                        vec[kp++] = lastval;
                    }
                }

                // Make it a discrete vector
                dvec x = discrete_vector(vec, q);
                int x_zero = x.x;
                int delta = x.y;

                // On-demand computation
                unsigned delta_hash = mul_table_hash(delta, q);
                global dvec *mul_table_mrk = &mul_table[mul_table_index(gp, g, delta_hash, gn)];
                global dvec *mul_table_entry = &mul_table[mul_table_index(gp, g, delta_hash + 1, gn)];

                if (mul_table_mrk->x != delta) // not computed
                {
                    // Normalize discrete vector
                    for (int kp = 0; kp < q; ++kp)
                    {
                        vec[kp] -= x_zero;
                    }

                    // Compute L[gp, g] * L[g, j] (0, delta)
                    int rs[Q_LIMIT];
                    for (int i = 0; i < q; ++i)
                    {
                        rs[i] = -q;
                    }

                    int ip = 0;
                    for (int i = low; i <= high; ++i, ++ip)
                    {
                        for (int k = a, kp = 0; k <= z; ++k, ++kp)
                        {
                            if ((k < i) || (k == i && k != z))
                                continue; // CAUTION: OUT OF CASE!
                            int sum = scores[scores_index(i, k, n)] + vec[kp];
                            rs[ip] = max(rs[ip], sum);
                        }
                    }

                    if (ip > 0) // Stuff vector entries smartly
                    {
                        int lastval = rs[ip - 1];
                        while (ip < q)
                        {
                            rs[ip++] = --lastval;
                        }
                    }

                    // Cache result
                    *mul_table_entry = discrete_vector(rs, q);

                    // Prevent further recomputation
                    if (z == a + (q - 1)) // full block
                    {
                        mul_table_mrk->x = delta;
                    }
                }

                dvec valmul = *mul_table_entry;
                int first = valmul.x;
                int second = valmul.y;
                first += x_zero;

                // Maximization over all g
                sdvec tmp = {first, second, q - 1};
                maxmul[jp] = delta_max(&maxmul[jp], &tmp);
            }

            // Restore
            int sum = maxmul[jp].x;
            int delta = maxmul[jp].y;

            for (int i = low, k = q - 1; i <= high; ++i, --k)
            {
                if (i > low)
                    sum -= delta & (1 << k) ? 1 : 0;

                if (sum > scores[scores_index(i, j, n)])
                {
                    scores[scores_index(i, j, n)] = sum;
                }

                // Update OCT status
                int oct_sum = oct_scores[oct_scores_index(i, j, n)];
                if ((i != high && sum >= oct_sum) || (sum > oct_sum))
                {
                    octs[octs_index(i, j, n)] = false;
                    if (sig_oct[sig_oct_index(i / q, j, gn)] & (1 << k))
                        sig_oct[sig_oct_index(i / q, j, gn)] -= (1 << k);
                }
            }
        }
    }
}

void nussinov_ts4r_routine(
    global dvec *mul_table,
    global char *g_table,
    global int *scores,
    global bool *octs,
    global int *sig_oct,
    global sdvec *dmaxmul,
           int n, int q,
           int j_low, int j_high,
           int gp, int gn, int BS)
{
    const int rank = get_local_id(0);
    const int stride = get_local_size(0);

    for (int g = (gp + 1) + rank; g < (j_high / q); g += stride)
    {
        for (int j = j_low; j <= j_high; ++j)
        {
            // Shortcuts
            int jp = j - j_low;
            int gj = j / q;

            // Exclude corner block
            if (g >= gj)
                continue;

            // Global boundaries
            int low = q * gp;
            int high = min(low + (q - 1), j - 2);

            // Particular boundaries
            int a = q * g;
            int z = min(a + (q - 1), j - 1);

            // Must satisfy sparsity properties
            if (gp + 1 < g && z < j - 1) // Protect necessary terms
            {
                // Retrieve sig_oct[g][j]
                int m = sig_oct[sig_oct_index(g, j, gn)];
                unsigned m_hash = g_table_hash(m, q);

                if (m == 0)
                {
                    continue; // Ignore current g
                }

                bool satisfy = false;

                bool g_table_a_mrk = (m == g_table[g_table_index(g, m_hash, 2 * gp, gn)]);
                bool g_table_b_mrk = (m == g_table[g_table_index(g, m_hash, 2 * gp + 1, gn)]);

                if (!g_table_b_mrk ||
                    !g_table_a_mrk || g_table[g_table_index(g, m_hash + 1, 2 * gp, gn)])
                {
                    satisfy = true; // Do not ignore current g
                }
                else if (!g_table[g_table_index(g, m_hash + 1, 2 * gp + 1, gn)])
                {
                    satisfy = satisfy_sublogic(
                        g_table,
                        scores,
                        octs,
                        low, high,
                        a, z,
                        n, m, m_hash,
                        j, g, gp, gn);
                }

                if (!satisfy)
                {
                    continue; // Ignore current g
                }
            }

            // Collecting L[g, j]
            int vec[Q_LIMIT];
            for (int i = 0; i < q; ++i)
            {
                vec[i] = 0;
            }

            int kp = 0;
            for (int k = a; k <= z; ++k, ++kp)
            {
                vec[kp] = scores[scores_index(k, j, n)];
            }

            if (kp > 0) // Stuff vector entries
            {
                int lastval = vec[kp - 1];
                while (kp < q)
                {
                    vec[kp++] = lastval;
                }
            }

            // Make it a discrete vector
            dvec x = discrete_vector(vec, q);
            int x_zero = x.x;
            int delta = x.y;

            // On-demand computation
            unsigned delta_hash = mul_table_hash(delta, q);
            global dvec *mul_table_mrk = &mul_table[mul_table_index(gp, g, delta_hash, gn)];
            global dvec *mul_table_entry = &mul_table[mul_table_index(gp, g, delta_hash + 1, gn)];

            if (mul_table_mrk->x != delta) // not computed
            {
                // Normalize discrete vector
                for (int kp = 0; kp < q; ++kp)
                {
                    vec[kp] -= x_zero;
                }

                // Compute L[gp, g] * L[g, j] (0, delta)
                int rs[Q_LIMIT];
                for (int i = 0; i < q; ++i)
                {
                    rs[i] = -q;
                }

                int ip = 0;
                for (int i = low; i <= high; ++i, ++ip)
                {
                    for (int k = a, kp = 0; k <= z; ++k, ++kp)
                    {
                        if ((k < i) || (k == i && k != z))
                            continue; // CAUTION: OUT OF CASE!
                        int sum = scores[scores_index(i, k, n)] + vec[kp];
                        rs[ip] = max(rs[ip], sum);
                    }
                }

                if (ip > 0) // Stuff vector entries smartly
                {
                    int lastval = rs[ip - 1];
                    while (ip < q)
                    {
                        rs[ip++] = --lastval;
                    }
                }

                // Cache result
                *mul_table_entry = discrete_vector(rs, q);

                // Prevent further recomputation
                if (z == a + (q - 1)) // full block
                {
                    mul_table_mrk->x = delta;
                }
            }

            dvec valmul = *mul_table_entry;
            int first = valmul.x;
            int second = valmul.y;
            first += x_zero;

            // Maximization over all g
            dmaxmul[dmaxmul_index(gp, jp, g - (gp + 1), q, gn, BS)] = (sdvec) {first, second, q - 1};
        }
    }
}

bool satisfy_sublogic(
    global char *g_table,
    global int *scores,
    global bool *octs,
           int low, int high,
           int a, int z,
           int n, int m, unsigned m_hash,
           int j, int g, int gp, int gn)
{
    for (int i = low; i <= high; ++i)
    {
        for (int k = a; k <= z; ++k)
        {
            if ((octs[octs_index(k, j, n)])
                && (i == n || scores[scores_index(i, k, n)] > scores[scores_index(i + 1, k, n)]))
            {
                g_table[g_table_index(g, m_hash, 2 * gp, gn)] = m;
                g_table[g_table_index(g, m_hash + 1, 2 * gp, gn)] = 1;
                return true;
            }
        }
    }

    g_table[g_table_index(g, m_hash, 2 * gp + 1, gn)] = m;
    g_table[g_table_index(g, m_hash + 1, 2 * gp + 1, gn)] = 1;
    return false;
}

sdvec delta_max(const sdvec *v, const sdvec *w)
{
    const int size = v->z;
    dvec rs = delta_max_aux((dvec) {v->x, v->y}, (dvec) {w->x, w->y}, size);

    return (sdvec) {rs.x, rs.y, size};
}

sdvec delta_max_glob(const sdvec *v, global const sdvec *w)
{
    const int size = v->z;
    dvec rs = delta_max_aux((dvec) {v->x, v->y}, (dvec) {w->x, w->y}, size);

    return (sdvec) {rs.x, rs.y, size};
}

dvec delta_max_aux(dvec v, dvec w, const int size)
{
    int v0 = v.x;
    int w0 = w.x;

    if (v0 > w0)
    {
        // Swap
        dvec tmp = v;
        v = w;
        w = tmp;

        v0 = v.x;
        w0 = w.x;
    }

    // w0 >= v0
    int diff = w0 - v0;
    if (diff >= size)
        return w;

    int dv = v.y;
    int dw = w.y;

    int x[Q_LIMIT];
    for (int i = 0; i < size + 1; ++i)
    {
        x[i] = 0;
    }

    int pos = 0;
    x[pos++] = max(v0, w0);

    int sum1 = v0; int sum2 = w0;
    for (int k = size - 1; k >= 0; --k) {
        sum1 -= dv & (1 << k) ? 1: 0;
        sum2 -= dw & (1 << k) ? 1: 0;
        x[pos++] = max(sum1, sum2);
    }

    dvec rs = discrete_vector(x, size + 1);

    return rs;
}

dvec discrete_vector(const int *vec, int size)
{
    int rs = 0;

    for (int i = size - 1, q = 0; i >= 1; --i, ++q)
    {
        if (vec[i - 1] - vec[i])
            rs += (1 << q);
    }

    return (dvec) {vec[0], rs};
}

int beta_score(char nt1, char nt2)
{
    // nt1 = toupper(nt1);
    // nt2 = toupper(nt2);

    if ((nt1 == 'A' && nt2 == 'U') || (nt1 == 'U' && nt2 == 'A'))
    {
        return 1;
    }

    if ((nt1 == 'G' && nt2 == 'C') || (nt1 == 'C' && nt2 == 'G'))
    {
        return 1;
    }

    return 0;
}

#endif
