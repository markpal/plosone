#define CL_HPP_ENABLE_EXCEPTIONS
#define CL_HPP_MINIMUM_OPENCL_VERSION 120
#define CL_HPP_TARGET_OPENCL_VERSION 120

#include "nussinov_ts4r.h"
#include <cmath>
#include <CL/cl.hpp>
#include <cassert>
#include <fstream>
#include <algorithm>
#include <iostream>

using namespace std;

using dvec = cl_int2;
using sdvec = cl_int3;
// Multi-dimensional index shortcuts
#include "nussinov_ts4r_shortcuts.inc.cpp"

/**
 * MAIN ENTRY
 */

int nussinov_ts4r(const string &sample)
{
    /**
     * Platform Layer
     */

    // Get list of OpenCL platforms.
    vector<cl::Platform> platforms;
    cl::Platform::get(&platforms);
    assert(platforms.size() > 0);
    auto platform = platforms.front();

    // Get list of devices.
    vector<cl::Device> devices;
    platform.getDevices(CL_DEVICE_TYPE_GPU, &devices);
    assert(devices.size() > 0);
    auto device = devices.front();

    // Create context
    cl::Context context({device});

    // Main queue
    cl::CommandQueue queue(context);

    // Load program
    ifstream stream("nussinov_ts4r.cl");
    string src(istreambuf_iterator<char>(stream), {});
    stream.close();

    cl::Program program(context, src);

    try
    {
        program.build();
    }
    #if MATRICS
    catch (...)
    {
        cerr << "Build failed." << endl;
        exit(EXIT_FAILURE);
    }
    #else
    catch (cl::BuildError &error)
    {
        string log = error.getBuildLog()[0].second;
        cerr << "Build failed:\n" << log << endl;
        exit(EXIT_FAILURE);
    }
    #endif


    /**
     * Runtime Layer
     */

    const int n = sample.size();
    const int q = round(log2(n));
    // const int q_max = (1 << q);
    const int gn = ceil(static_cast<double>(n + 1) / q);
    const int BS = ceil(static_cast<double>(TILE) / 1);

    // Sample string
    const size_t c_sample_size = (n + 1) * sizeof(char);
    char *c_sample = (char *) malloc(c_sample_size);
    copy(sample.cbegin(), sample.cend(), c_sample);
    c_sample[n] = '\0';
    cl::Buffer c_sample_bf(context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, c_sample_size, c_sample);

    // Lookup tables
    const int q_hash = (q - 1) / 2 + 1.5;
    const int q_max_hash = (1 << q_hash);
    const size_t mul_table_size = ((gn * (gn + 1)) / 2) * q_max_hash * sizeof(dvec);
    cl::Buffer mul_table_bf(context, CL_MEM_READ_WRITE, mul_table_size);

    // G Lookup table
    const int q_ghash = q / 2 + 1.5;
    const int q_max_ghash = (1 << q_ghash);
    const size_t g_table_size = gn * q_max_ghash * (2 * gn) * sizeof(char);
    cl::Buffer g_table_bf(context, CL_MEM_READ_WRITE, g_table_size);

    // Main tables
    const size_t scores_size = ((n + 1) * (n + 2) / 2) * sizeof(int);
    cl::Buffer scores_bf(context, CL_MEM_READ_WRITE, scores_size);

    const size_t oct_scores_size = (n + 1) * (n + 1) * sizeof(int);
    cl::Buffer oct_scores_bf(context, CL_MEM_READ_WRITE, oct_scores_size);

    // Optimally co-terminus
    const size_t octs_size = (n + 1) * (n + 1) * sizeof(bool);
    cl::Buffer octs_bf(context, CL_MEM_READ_WRITE, octs_size);

    const size_t sig_oct_size = (gn) * (n + 1) * sizeof(int);
    cl::Buffer sig_oct_bf(context, CL_MEM_READ_WRITE, sig_oct_size);

    // maxmul race
    const size_t dmaxmul_size = BS * q * gn * sizeof(sdvec);
    cl::Buffer dmaxmul_bf(context, CL_MEM_READ_WRITE, dmaxmul_size);

    // Initialize
    // PARCALL(n + 1, 1)

    try
    {
        cl::Kernel initialize_kernel(program, "initialize");
        int pos = 0;
        initialize_kernel.setArg(pos++, mul_table_bf);
        initialize_kernel.setArg(pos++, g_table_bf);
        initialize_kernel.setArg(pos++, scores_bf);
        initialize_kernel.setArg(pos++, oct_scores_bf);
        initialize_kernel.setArg(pos++, octs_bf);
        initialize_kernel.setArg(pos++, sig_oct_bf);
        initialize_kernel.setArg(pos++, n);
        initialize_kernel.setArg(pos++, gn);
        initialize_kernel.setArg(pos++, q);

        queue.enqueueNDRangeKernel(initialize_kernel, cl::NullRange, n + 1);
    }
    catch (...)
    {
        cerr << "Error: initialize_kernel." << endl;
        exit(EXIT_FAILURE);
    }

    // SYNC

    // Core computations
    // PARCALL(1, 1)

    const int workgroup_size = min((n + 1) / q - 1, 1024);

    for (int dd = 0; dd < gn; dd += BS)
    {
        for (int ggp = (gn - 1) - dd; ggp >= 0; ggp -= BS)
        {
            for (int d = dd; d < min(dd + BS, gn); ++d)
            {
                // PARCALL(BS, 1)

                try
                {
                    cl::Kernel coarse_routine_kernel(program, "nussinov_ts4r_coarse_routine");
                    int pos = 0;
                    coarse_routine_kernel.setArg(pos++, c_sample_bf);
                    coarse_routine_kernel.setArg(pos++, mul_table_bf);
                    coarse_routine_kernel.setArg(pos++, g_table_bf);
                    coarse_routine_kernel.setArg(pos++, scores_bf);
                    coarse_routine_kernel.setArg(pos++, oct_scores_bf);
                    coarse_routine_kernel.setArg(pos++, octs_bf);
                    coarse_routine_kernel.setArg(pos++, sig_oct_bf);
                    coarse_routine_kernel.setArg(pos++, dmaxmul_bf);
                    coarse_routine_kernel.setArg(pos++, n);
                    coarse_routine_kernel.setArg(pos++, q);
                    coarse_routine_kernel.setArg(pos++, gn);
                    coarse_routine_kernel.setArg(pos++, d);
                    coarse_routine_kernel.setArg(pos++, BS);
                    coarse_routine_kernel.setArg(pos++, ggp);

                    queue.enqueueNDRangeKernel(coarse_routine_kernel, cl::NullRange, BS * workgroup_size, workgroup_size);
                }
                catch (...)
                {
                    cerr << "Error: coarse_routine_kernel." << endl;
                    exit(EXIT_FAILURE);
                }

                // SYNC
            }
        }
    }

    // SYNC

    // Fetch result
    int grs = -1;
    queue.enqueueReadBuffer(scores_bf, CL_TRUE, sizeof(int) * scores_index(0, n, n), sizeof(int), &grs);

    // Free memory
    free(c_sample);

    // Return
    return grs;
}
