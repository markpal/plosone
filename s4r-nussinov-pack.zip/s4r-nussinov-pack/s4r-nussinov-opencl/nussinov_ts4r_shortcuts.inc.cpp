#define Q_LIMIT 20

inline int mul_table_index(int i, int j, int k, int gn) {
    int d = j - i;
    int ij = (d * gn - d * (d - 1) / 2) + i;
    return (k * (gn * (gn + 1)) / 2) + ij;
}

inline int g_table_index(int i, int j, int k, int gn) {
    return (j * (2 * gn) + k) * gn + i;
}

inline int scores_index(int i, int j, int n) {
    int d = j - i;
    return (d * (n + 1) - d * (d - 1) / 2) + i;
}

inline int oct_scores_index(int i, int j, int n) {
    return i * (n + 1) + j;
}

inline int octs_index(int i, int j, int n) {
    return i * (n + 1) + j;
}

inline int sig_oct_index(int i, int j, int gn) {
    return gn * j + i;
}

inline int dmaxmul_index(int gp, int i, int j, int q, int gn, int BS) {
    return ((gp % BS) * q + i) * gn + j;
}

inline unsigned mul_table_hash(int delta, int q)
{
    unsigned rs = 0;

    int lim = (q - 1) / 2 + 0.5;
    for (int i = 0; i < lim; ++i)
    {
        bool b1 = (delta & (1 << (2 * i)));
        bool b2 = (delta & (1 << (2 * i + 1)));
        if (b1 ^ b2)
            rs ^= 1 << (i + 1);
    }

    return rs;
}

inline unsigned g_table_hash(int delta, int q)
{
    unsigned rs = 0;

    int lim = q / 2 + 0.5;
    for (int i = 0; i < lim; ++i)
    {
        bool b1 = (delta & (1 << (2 * i)));
        bool b2 = (delta & (1 << (2 * i + 1)));
        if (b1 ^ b2)
            rs ^= 1 << (i + 1);
    }

    return rs;
}
