#ifndef NUSSINOV_H
#define NUSSINOV_H

#include "config.h"
#include <vector>
#include <string>

template <typename T>
using matrix = std::vector<std::vector<T>>;
void display_scores(const matrix<int> &m);

int beta_score(char nt1, char nt2);
int nussinov(const std::string &sample);

#endif // NUSSINOV_H
