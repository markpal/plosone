#include "handy_chrono.h"
#include "nussinov_ts4r.h"

#include <ctime>
#include <fstream>
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    string rna;
    rna = "CCGGCAUG";
    rna = "CCGGCAUGAAAAAAAAGGUUUAUAUUCCCACACAGAGGA";

    if (1)
    {
        ifstream file("../data/data2k.txt");
        if (file)
        {
            file >> rna;
            file.close();
        }
    }

    int n = rna.size();
    cout << "Data size: " << n << endl;
    cout << fixed << setprecision(2);

    int score;
    chrono_clock start, end;

    start = now();
    score = nussinov_ts4r(rna);
    end = now();

    cout << ">> TS4Russ [" << score << "] "
         << "(" << duration(start, end) << "s)\n";
}
