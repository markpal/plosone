#ifndef CONFIG_H
#define CONFIG_H

#define TILE 256
#define MATRICS 0

#endif // CONFIG_H
