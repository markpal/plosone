#ifndef NUSSINOV_S4R_H
#define NUSSINOV_S4R_H

#include "nussinov_4r.h"

int nussinov_s4r(const std::string &sample);

#endif // NUSSINOV_S4R_H
