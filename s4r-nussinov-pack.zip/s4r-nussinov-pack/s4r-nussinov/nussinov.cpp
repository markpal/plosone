#include "nussinov.h"
#include <iomanip>
#include <iostream>
#include <set>
#include <stdexcept>
using namespace std;

bool is_valid(char nt)
{
    static const set<char> l = {'A', 'U', 'G', 'C'};

    return l.find(nt) != l.end();
}

int beta_score(char nt1, char nt2)
{
    nt1 = toupper(nt1);
    nt2 = toupper(nt2);

    if (!is_valid(nt1) || !is_valid(nt2))
        throw new runtime_error("Invalid nucleotide.");

    for (auto valid_pair : vector<vector<char>>({{'A', 'U', 1}, {'G', 'C', 1}}))
    {
        if ((nt1 == valid_pair[0] && nt2 == valid_pair[1])
            || (nt2 == valid_pair[0] && nt1 == valid_pair[1]))
        {
            return valid_pair[2];
        }
    }

    return 0;
}

int nussinov(const string &sample)
{
    int n = sample.size();
    matrix<int> scores(n + 1, vector<int>(n + 1, 0));
    matrix<int> pscores(n + 1, vector<int>(n + 1, -1));

    // Core computations
    for (int d = 2; d <= n; ++d)
    {
        #pragma omp parallel for schedule(dynamic, 1) num_threads(NUM_THREADS)
        for (int i = n - d; i >= 0; --i)
        {
            int j = i + d;

            scores[i][j] = scores[i + 1][j - 1]
                + beta_score(sample[i], sample[j - 1]);

            for (int k = i + 1; k <= j - 1; ++k)
            {
                int sum = scores[i][k] + scores[k][j];
                pscores[i][j] = max(pscores[i][j], sum);
            }

            scores[i][j] = max(scores[i][j], pscores[i][j]);
        }
    }

    return scores[0][n];
}

void display_scores(const matrix<int> &m)
{
    int n = m.size();

    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            if (i > j)
                cout << right << setw(4) << "";
            else
                cout << right << setw(4) << m[i][j];
        }

        cout << endl;
    }
}
