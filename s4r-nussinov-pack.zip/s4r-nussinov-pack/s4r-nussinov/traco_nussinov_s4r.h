#ifndef TRACO_NUSSINOV_S4R_H
#define TRACO_NUSSINOV_S4R_H

#include "nussinov_s4r.h"
#include <tuple>

using sdvec = std::tuple<int, int, int>;
sdvec operator^=(sdvec &a, const sdvec &b);
sdvec delta_max(const sdvec &v, const sdvec &w);

int traco_nussinov_s4r(const std::string &sample);

#endif // TRACO_NUSSINOV_S4R_H
