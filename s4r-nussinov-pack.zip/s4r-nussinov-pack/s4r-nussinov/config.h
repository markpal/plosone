#ifndef CONFIG_H
#define CONFIG_H

#define NUM_THREADS 4
#define B 128

#endif // CONFIG_H
