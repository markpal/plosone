#include "nussinov_4r.h"
#include "math.h"
#include <map>
#include <iostream>
#include <iomanip>
#include <bitset>
#include <algorithm>
using namespace std;

int nussinov_4r(const string &sample)
{
    int n = sample.size();
    int q = round(log2(n));
    int gn = ceil(static_cast<double>(n + 1) / q);

    // Lookup tables
    // int q_max = pow(2, q);
    matrix<unordered_map<int, dvec>> mul_table(gn, vector<unordered_map<int, dvec>>(gn));

    // Main tables
    matrix<int> scores(n + 1, vector<int>(n + 1, 0));
    matrix<int> pscores(n + 1, vector<int>(n + 1, 0));

    // Core computations
    for (int j = 2; j <= n; ++j)
    {

        for (int i = j - 2; i >= 0; --i)
        {
            scores[i][j] = max({
                scores[i][j - 1],
                scores[i + 1][j],
                scores[i + 1][j - 1] + beta_score(sample[i], sample[j - 1])});
        }

        int gj = j / q;

        for (int gp = gj; gp >= 0; --gp)
        {
            // Global boundaries
            int low = q * gp;
            int high = min(low + (q - 1), j - 2);

            dvec maxmul = {-1, 0};
            for (int g = gp; g <= gj; ++g)
            {
                // Particular boundaries
                int a = q * g;
                int z = min(a + (q - 1), j - 1);

                // Collecting L[g, j]
                vector<int> vec(q, 0);
                int kp = 0;
                for (int k = a; k <= z; ++k, ++kp)
                {
                    vec[kp] = scores[k][j];
                }

                if (kp > 0) // Stuff vector entries
                {
                    int lastval = vec[kp - 1];
                    while (kp < q)
                    {
                        vec[kp++] = lastval;
                    }
                }

                // Make it a discrete vector
                dvec x = discrete_vector(vec);
                auto &[x_zero, delta] = x;

                // On-demand computation
                auto &mul_table_entry = mul_table[gp][g][delta];
                if (!(mul_table_entry.second & (1 << q))) // not computed
                {
                    // Normalize discrete vector
                    for (int kp = 0; kp < q; ++kp)
                    {
                        vec[kp] -= x_zero;
                    }

                    // Compute L[gp, g] * L[g, j] (0, delta)
                    vector<int> rs(q, -q);

                    int ip = 0;
                    for (int i = low; i <= high; ++i, ++ip)
                    {
                        for (int k = a, kp = 0; k <= z; ++k, ++kp)
                        {
                            if ((k < i) || (k == i && k != z))
                                continue; // CAUTION: OUT OF CASE!
                            int sum = scores[i][k] + vec[kp];
                            rs[ip] = max(rs[ip], sum);
                        }
                    }

                    if (ip > 0) // Stuff vector entries smartly
                    {
                        int lastval = rs[ip - 1];
                        while (ip < q)
                        {
                            rs[ip++] = --lastval;
                        }
                    }

                    // Cache result
                    mul_table_entry = discrete_vector(rs);

                    // Prevent further recomputation
                    if (z == a + (q - 1)) // full block
                    {
                        mul_table_entry.second |= (1 << q);
                    }
                }

                dvec valmul = mul_table_entry;
                valmul.first += x_zero;

                // Maximization over all g
                maxmul = delta_max(maxmul, valmul, q - 1);
            }

            // Restore
            int sum = maxmul.first;
            int delta = maxmul.second;

            for (int i = low, k = q - 1; i <= high; ++i, --k)
            {
                if (i > low)
                    sum -= delta & (1 << k) ? 1 : 0;
                scores[i][j] = max(scores[i][j], pscores[i][j] = sum);
            }
        }
    }


    return scores[0][n];
}

dvec delta_max(dvec v, dvec w, const int size)
{
    int v0 = v.first;
    int w0 = w.first;

    if (v0 > w0)
        return delta_max(w, v, size);

    // w0 >= v0
    int diff = w0 - v0;
    if (diff >= size)
        return w;

    int dv = v.second;
    int dw = w.second;

    vector<int> x;
    x.reserve(size + 1);
    x.push_back(max(v0, w0));

    int sum1 = v0; int sum2 = w0;
    for (int k = size - 1; k >= 0; --k) {
        sum1 -= dv & (1 << k) ? 1: 0;
        sum2 -= dw & (1 << k) ? 1: 0;
        x.push_back(max(sum1, sum2));
    }

    return discrete_vector(x);
}

dvec discrete_vector(const vector<int> &vec)
{
    int rs = 0;

    for (int i = vec.size() - 1, q = 0; i >= 1; --i, ++q)
    {
        if (vec[i - 1] - vec[i])
            rs += (1 << q);
    }

    return {vec[0], rs};
}
