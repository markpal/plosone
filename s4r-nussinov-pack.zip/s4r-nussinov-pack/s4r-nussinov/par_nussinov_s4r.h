#ifndef PAR_NUSSINOV_S4R_H
#define PAR_NUSSINOV_S4R_H

#include "traco_nussinov_s4r.h"

int par_nussinov_s4r(const std::string &sample);

#endif // PAR_NUSSINOV_S4R_H
