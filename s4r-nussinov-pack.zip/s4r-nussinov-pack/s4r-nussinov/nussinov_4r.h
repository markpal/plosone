#ifndef FOUR_RUSSIANS_NUSSINOV_H
#define FOUR_RUSSIANS_NUSSINOV_H

#include "nussinov.h"
#include <unordered_set>
#include <unordered_map>

using dvec = std::pair<int, int>;
dvec delta_max(dvec v, dvec w, const int size);
dvec discrete_vector(const std::vector<int> &vec);

int nussinov_4r(const std::string &sample);

#endif // FOUR_RUSSIANS_NUSSINOV_H
