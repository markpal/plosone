#include "nussinov_s.h"
using namespace std;

int nussinov_s(const string &sample)
{
    int n = sample.size();
    matrix<int> scores(n + 1, vector<int>(n + 1));
    matrix<int> pscores(n + 1, vector<int>(n + 1));
    matrix<bool> octs(n + 1, vector<bool>(n + 1, false));

    // Fill up diagonals
    for (int i = 0; i <= n; ++i)
    {
        scores[i][i] = 0;
        pscores[i][i] = 0;
    }

    // Fill up sup-diagonals
    for (int i = 0; i < n; ++i)
    {
        scores[i][i + 1] = 0;
        pscores[i][i + 1] = 0;
    }

    // Core computations
    for (int j = 2; j <= n; ++j)
    {
        for (int i = 0; i <= j - 2; ++i)
        {
            scores[i][j] = scores[i + 1][j - 1]
                + beta_score(sample[i], sample[j - 1]);
        }

        for (int i = j - 2; i >= 0; --i)
        {
            int k = i + 1;
            int sum = scores[i][k] + scores[k][j];
            pscores[i][j] = sum;

            for (k = i + 2; k <= j - 2; ++k)
            {
                if (scores[i][k] > scores[i + 1][k]) // STEP
                {
                    if (octs[k][j]) // OCT
                    {
                        sum = scores[i][k] + scores[k][j];
                        pscores[i][j] = max(pscores[i][j], sum);
                    }
                }
            }

            k = j - 1;
            sum = scores[i][k] + scores[k][j];
            pscores[i][j] = max(pscores[i][j], sum);

            // Update if necessary
            if (pscores[i][j] > scores[i][j]) {
                scores[i][j] = pscores[i][j];
            } else if (pscores[i][j] < scores[i][j]) {
                octs[i][j] = true;
            }
        }
    }

    return scores[0][n];
}
