#include "traco_nussinov_s4r.h"
#include "math.h"
#include <algorithm>
#include <iostream>
using namespace std;

int traco_nussinov_s4r(const string &sample)
{
    const int n = sample.size();
    const int q = round(log2(n));
    const int gn = ceil(static_cast<double>(n + 1) / q);
    const int BS = ceil(static_cast<double>(B) / 4);

    // Lookup tables
    int q_max = pow(2, q);
    matrix<unordered_map<int, dvec>> mul_table(gn, vector<unordered_map<int, dvec>>(gn));

    // G Lookup table
    matrix<vector<bool>> g_table(gn, matrix<bool>(q_max, vector<bool>(2 * gn)));

    // Main tables
    matrix<int> scores(n + 1, vector<int>(n + 1, 0));
    matrix<int> oct_scores(n + 1, vector<int>(n + 1, 0));

    // Optimally co-terminus
    matrix<bool> octs(n + 1, vector<bool>(n + 1, true));
    matrix<int> sig_oct(gn, vector<int>(n + 1, q_max - 1));

    // Core computations
    for (int dd = 0; dd < gn; dd += BS)
    {
        #pragma omp parallel num_threads(NUM_THREADS)
        for (int ggp = (gn - 1) - dd; ggp >= 0; ggp -= BS)
        {
            for (int d = dd; d < min(dd + BS, gn); ++d)
            {
                #pragma omp for schedule(dynamic, 1)
                for (int gp = min(ggp, (gn - 1) - d); gp >= max(ggp - BS + 1, 0); --gp)
                {
                    int j_low = q * (gp + d);
                    int j_high = min(j_low + (q - 1), n);

                    vector<sdvec> maxmul(q, {-1, 0, q - 1});

                    /**
                     * Run blocks gp < g < gj
                     */
                    for (int g = gp + 1; g < (j_high / q); ++g)
                    {
                        for (int j = j_low; j <= j_high; ++j)
                        {
                            // Shortcuts
                            int jp = j - j_low;
                            int gj = j / q;

                            // Exclude corner block
                            if (g >= gj)
                                continue;

                            // Global boundaries
                            int low = q * gp;
                            int high = min(low + (q - 1), j - 2);

                            // Particular boundaries
                            int a = q * g;
                            int z = min(a + (q - 1), j - 1);

                            // Must satisfy sparsity properties
                            if (gp + 1 < g && z < j - 1) // Protect necessary terms
                            {
                                // Retrieve sig_oct[g][j]
                                int m = sig_oct[g][j];

                                if (m == 0)
                                {
                                    continue; // Ignore current g
                                }

                                bool satisfy = false;

                                auto &entry = g_table[g][m];

                                if (entry[(2 * gp)])
                                {
                                    satisfy = true;
                                }
                                else if (!entry[(2 * gp) + 1])
                                {
                                    satisfy = [&] {
                                        for (int i = low; i <= high; ++i)
                                        {
                                            for (int k = a; k <= z; ++k)
                                            {
                                                if ((octs[k][j])                                    // OCT
                                                    && (i == n || scores[i][k] > scores[i + 1][k])) // STEP
                                                {
                                                    entry[(2 * gp)] = true;
                                                    return true;
                                                }
                                            }
                                        }

                                        entry[(2 * gp) + 1] = true;
                                        return false;
                                    }();
                                }

                                if (!satisfy)
                                {
                                    continue; // Ignore current g
                                }
                            }

                            // Collecting L[g, j]
                            vector<int> vec(q, 0);
                            int kp = 0;
                            for (int k = a; k <= z; ++k, ++kp)
                            {
                                vec[kp] = scores[k][j];
                            }

                            if (kp > 0) // Stuff vector entries
                            {
                                int lastval = vec[kp - 1];
                                while (kp < q)
                                {
                                    vec[kp++] = lastval;
                                }
                            }

                            // Make it a discrete vector
                            dvec x = discrete_vector(vec);
                            auto &[x_zero, delta] = x;

                            // On-demand computation
                            auto &mul_table_entry = mul_table[gp][g][delta];
                            if (!(mul_table_entry.second & (1 << q))) // not computed
                            {
                                // Normalize discrete vector
                                for (int kp = 0; kp < q; ++kp)
                                {
                                    vec[kp] -= x_zero;
                                }

                                // Compute L[gp, g] * L[g, j] (0, delta)
                                vector<int> rs(q, -q);

                                int ip = 0;
                                for (int i = low; i <= high; ++i, ++ip)
                                {
                                    for (int k = a, kp = 0; k <= z; ++k, ++kp)
                                    {
                                        if ((k < i) || (k == i && k != z))
                                            continue; // CAUTION: OUT OF CASE!
                                        int sum = scores[i][k] + vec[kp];
                                        rs[ip] = max(rs[ip], sum);
                                    }
                                }

                                if (ip > 0) // Stuff vector entries smartly
                                {
                                    int lastval = rs[ip - 1];
                                    while (ip < q)
                                    {
                                        rs[ip++] = --lastval;
                                    }
                                }

                                // Cache result
                                mul_table_entry = discrete_vector(rs);

                                // Prevent further recomputation
                                if (z == a + (q - 1)) // full block
                                {
                                    mul_table_entry.second |= (1 << q);
                                }
                            }

                            dvec valmul = mul_table_entry;
                            auto &[first, second] = valmul;
                            first += x_zero;

                            // Maximization over all g
                            maxmul[jp] ^= sdvec{first, second, q - 1};
                        }
                    }

                    /**
                     * Run blocks gp and gj
                     */
                    for (int j = j_low; j <= j_high; ++j)
                    {
                        // Shortcuts
                        int jp = j - j_low;
                        int gj = j / q;

                        // Global boundaries
                        int low = q * gp;
                        int high = min(low + (q - 1), j - 2);

                        // Initialization
                        for (int i = high; i >= low; --i)
                        {
                            scores[i][j] = max({
                                scores[i][j - 1],
                                scores[i + 1][j],
                                oct_scores[i][j] = scores[i + 1][j - 1] + beta_score(sample[i], sample[j - 1])
                            });
                        };

                        for (int g = gp; g <= gj; g = (g != gj) ? gj : gn)
                        {
                            // Particular boundaries
                            int a = q * g;
                            int z = min(a + (q - 1), j - 1);

                            // Collecting L[g, j]
                            vector<int> vec(q, 0);
                            int kp = 0;
                            for (int k = a; k <= z; ++k, ++kp)
                            {
                                vec[kp] = scores[k][j];
                            }

                            if (kp > 0) // Stuff vector entries
                            {
                                int lastval = vec[kp - 1];
                                while (kp < q)
                                {
                                    vec[kp++] = lastval;
                                }
                            }

                            // Make it a discrete vector
                            dvec x = discrete_vector(vec);
                            auto &[x_zero, delta] = x;

                            // On-demand computation
                            auto &mul_table_entry = mul_table[gp][g][delta];
                            if (!(mul_table_entry.second & (1 << q))) // not computed
                            {
                                // Normalize discrete vector
                                for (int kp = 0; kp < q; ++kp)
                                {
                                    vec[kp] -= x_zero;
                                }

                                // Compute L[gp, g] * L[g, j] (0, delta)
                                vector<int> rs(q, -q);

                                int ip = 0;
                                for (int i = low; i <= high; ++i, ++ip)
                                {
                                    for (int k = a, kp = 0; k <= z; ++k, ++kp)
                                    {
                                        if ((k < i) || (k == i && k != z))
                                            continue; // CAUTION: OUT OF CASE!
                                        int sum = scores[i][k] + vec[kp];
                                        rs[ip] = max(rs[ip], sum);
                                    }
                                }

                                if (ip > 0) // Stuff vector entries smartly
                                {
                                    int lastval = rs[ip - 1];
                                    while (ip < q)
                                    {
                                        rs[ip++] = --lastval;
                                    }
                                }

                                // Cache result
                                mul_table_entry = discrete_vector(rs);

                                // Prevent further recomputation
                                if (z == a + (q - 1)) // full block
                                {
                                    mul_table_entry.second |= (1 << q);
                                }
                            }

                            dvec valmul = mul_table_entry;
                            auto &[first, second] = valmul;
                            first += x_zero;

                            // Maximization over all g
                            maxmul[jp] ^= sdvec{first, second, q - 1};
                        }

                        // Restore
                        auto &[sum, delta, size] = maxmul[jp];

                        for (int i = low, k = q - 1; i <= high; ++i, --k)
                        {
                            if (i > low)
                                sum -= delta & (1 << k) ? 1 : 0;

                            if (sum > scores[i][j])
                            {
                                scores[i][j] = sum;
                            }

                            // Update OCT status
                            int oct_sum = oct_scores[i][j];
                            if ((i != high && sum >= oct_sum) || (sum > oct_sum))
                            {
                                octs[i][j] = false;
                                if (sig_oct[i / q][j] & (1 << k))
                                    sig_oct[i / q][j] -= (1 << k);
                            }
                        }
                    }
                }
            }
        }
    }

    return scores[0][n];
}

sdvec delta_max(const sdvec &v, const sdvec &w)
{
    const auto &[vfirst, vsecond, vsize] = v;
    const auto &[wfirst, wsecond, wsize] = w;

    const int size = vsize;
    dvec rs = delta_max({vfirst, vsecond}, {wfirst, wsecond}, size);

    return {rs.first, rs.second, size};
}

sdvec operator^=(sdvec &a, const sdvec &b)
{
    return a = delta_max(a, b);
}
