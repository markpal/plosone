#include "handy_chrono.h"
#include "nussinov.h"
#include "nussinov_4r.h"
#include "nussinov_s.h"
#include "nussinov_s4r.h"
#include "par_nussinov_s4r.h"
#include "traco_nussinov_s4r.h"

#include <ctime>
#include <fstream>
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    string rna;
    rna = "CCGGCAUG";
    rna = "CCGGCAUGAAAAAAAAGGUUUAUAUUCCCACACAGAGGA";
    rna = "CCGGCAUGAAAAAAAAGGUUUAUAUUCCCACACAGAGGAAAAUACCCCGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGAAUUUUUUCCCUUUCCUCU";

    if constexpr(1)
    {
        ifstream file("../data/data2k.txt");
        if (file)
        {
            file >> rna;
            file.close();
        }
    }

    int n = rna.size();
    cout << "Data size: " << n << endl;
    cout << "Threads: " << NUM_THREADS << endl;
    cout << fixed << setprecision(2);

    int score;
    chrono_clock start, end;

    /**
     * Traditional
     */
    cout << "\nTraditional" << endl;

    start = now();
    score = nussinov(rna);
    end = now();

    cout << ">> Class  [" << score << "] "
         << "(" << duration(start, end) << "s)\n" << flush;

    /**
     * Doubly sped up
     */
    cout << "\nDoubly Sped Up" << endl;

    start = now();
    score = par_nussinov_s4r(rna);
    end = now();

    cout << ">> PS4R   [" << score << "] "
         << "(" << duration(start, end) << "s)\n";

    start = now();
    score = traco_nussinov_s4r(rna);
    end = now();

    cout << ">> PTS4R  [" << score << "] "
         << "(" << duration(start, end) << "s)\n";

    /**
     * Side versions
     */
    cout << "\nSide versions (not parallel)" << endl;

    start = now();
    score = nussinov_4r(rna);
    end = now();

    cout << ">> 4Russ. [" << score << "] "
         << "(" << duration(start, end) << "s)\n";

    start = now();
    score = nussinov_s4r(rna);
    end = now();

    cout << ">> S4Russ [" << score << "] "
         << "(" << duration(start, end) << "s)\n";

    // End.
    // cout << endl;
}
