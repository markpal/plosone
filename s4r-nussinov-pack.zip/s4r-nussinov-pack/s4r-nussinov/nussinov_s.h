#ifndef SPARSE_NUSSINOV_H
#define SPARSE_NUSSINOV_H

#include "nussinov.h"

int nussinov_s(const std::string &sample);

#endif // SPARSE_NUSSINOV_H
